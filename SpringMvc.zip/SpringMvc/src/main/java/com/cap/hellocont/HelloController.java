package com.cap.hellocont;

//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloController {
@RequestMapping("/")
public String showMessage() {
	return "index";
}

/*@RequestMapping("/login")
   public String authenticateUser(HttpServletRequest request, HttpServletResponse response) {
	   String username = request.getParameter("userName");
	   String password = request.getParameter("Password");
	   System.out.println("username :"+username+ "passowrd :"+password);
	   if(username.equals("abcd") && password.equals("abcd")) {
		   return "success";
	   }else
		   
	   return "Failure";
	   
   }*/
/*
public String authenticateUser(@RequestParam String username, @RequestParam String password) {
	return password;
	
}*/
}
